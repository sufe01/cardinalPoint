let siteID = 'Cardinal-Point' // Set an UNIQUE ID
let termsURL = 'policy.html' // You can include custom URL to Terms and Conditions Here (LEAVE THIS BLANK IF YOU WANT TO KEEP THE DEFAULT SETUP)
